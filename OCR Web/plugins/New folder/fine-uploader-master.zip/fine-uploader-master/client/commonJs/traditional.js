"use strict";

module.exports = require("../fine-uploader/fine-uploader");
