"use strict";

module.exports = require("../../all.fine-uploader/all.fine-uploader.core");
